<?php
// Device Types
// $LANG['plugin_customfields']['device_type']['Computer']        = $LANG['Menu'][0];
// $LANG['plugin_customfields']['device_type']['NetworkEquipment']= $LANG['Menu'][1];
// $LANG['plugin_customfields']['device_type']['Printer']         = $LANG['Menu'][2];
// $LANG['plugin_customfields']['device_type']['Monitor']         = $LANG['Menu'][3];
// $LANG['plugin_customfields']['device_type']['Peripheral']      = $LANG['Menu'][16];
// $LANG['plugin_customfields']['device_type']['Software']        = $LANG['Menu'][4];
// $LANG['plugin_customfields']['device_type']['Phone']           = $LANG['Menu'][34];
// $LANG['plugin_customfields']['device_type']['CartridgeItem']       = $LANG['Menu'][21];
// $LANG['plugin_customfields']['device_type']['ConsumableItem']      = $LANG['Menu'][32];
// $LANG['plugin_customfields']['device_type']['Contact']         = $LANG['Menu'][22];
// $LANG['plugin_customfields']['device_type']['Supplier']        = $LANG['Menu'][23];
// $LANG['plugin_customfields']['device_type']['Contract']        = $LANG['Menu'][25];
// $LANG['plugin_customfields']['device_type']['Document']        = $LANG['Menu'][27];
// $LANG['plugin_customfields']['device_type']['Ticket']          = $LANG['Menu'][5];
// $LANG['plugin_customfields']['device_type']['User']            = $LANG['Menu'][14];
// $LANG['plugin_customfields']['device_type']['Group']           = $LANG['Menu'][36];
// $LANG['plugin_customfields']['device_type']['Entity']          = $LANG['Menu'][37];
// $LANG['plugin_customfields']['device_type']['NetworkPort']     = $LANG['networking'][6];
// $LANG['plugin_customfields']['device_type']['ComputerDisk']    = $LANG['computers'][8];
// $LANG['plugin_customfields']['device_type']['Device']          = $LANG['Menu'][30];

// $LANG['plugin_customfields']['component_type']['DeviceMotherboard']  = $LANG['devices'][5];
// $LANG['plugin_customfields']['component_type']['DeviceProcessor']    = $LANG['devices'][4];
// $LANG['plugin_customfields']['component_type']['DeviceMemory']       = $LANG['devices'][6];
// $LANG['plugin_customfields']['component_type']['DeviceHardDrive']    = $LANG['devices'][1];
// $LANG['plugin_customfields']['component_type']['DeviceNetworkCard']  = $LANG['devices'][3];
// $LANG['plugin_customfields']['component_type']['DeviceDrive']        = $LANG['devices'][19];
// $LANG['plugin_customfields']['component_type']['DeviceControl']      = $LANG['devices'][20];
// $LANG['plugin_customfields']['component_type']['DeviceGraphicCard']  = $LANG['devices'][2];
// $LANG['plugin_customfields']['component_type']['DeviceSoundCard']    = $LANG['devices'][7];
// $LANG['plugin_customfields']['component_type']['DevicePci']          = $LANG['devices'][21];
// $LANG['plugin_customfields']['component_type']['DeviceCase']         = $LANG['devices'][22];
// $LANG['plugin_customfields']['component_type']['DevicePowerSupply']  = $LANG['devices'][23];
